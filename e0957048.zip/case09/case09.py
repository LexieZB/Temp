import urllib, urllib2
from HTMLParser import HTMLParser
	
csrf = ""
	
class Parser(HTMLParser):
	def handle_startendtag(self, tag, attrs):
		if tag == 'input':
			attr_dict = dict(attrs)
			if attr_dict['name'] == 'csrf_token':
				global csrf
				csrf = attr_dict['value']
	
# Get a copy of the original page
url = 'http://www.wsb.com/Homework3/case09.php'
req = urllib2.Request(url)
res = urllib2.urlopen(req)
content = res.read()
	
# Feed the content to the parser
parser = Parser()
parser.feed(content)

# Construct the new request with the required info
post_values = dict(data='Weibo', csrf_token=csrf)
data = urllib.urlencode(post_values)
post_req = urllib2.Request(url, data)
post_res = urllib2.urlopen(post_req)
	
with open('target.html', 'w') as f:
	f.write(post_res.read())
	
import webbrowser
new = 2
webbrowser.open('target.html', new=new)