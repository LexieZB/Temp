# Bug Categoty: CSRF Predictable tokens
# target: prepare a script with a simple form to submit a message to case09.php


# The logic of case09.php is:
# case09 creates a HTML form and accepts a user input
# When the user submits the form, the data is sent via HTTP POST method to the same page
# Then the PHP code checks 'data' and 'csrf_token' variable
# If conditions are true, the code echoes a success message along with the 'data' input by user.


# Exploit:
# Case09 website is not verifying that the request is originating from a trusted source, and is blindly accepting the request based on the presence of a valid CSRF token.
# So we can conduct attack base on this.
# First, we send a GET request to the case09 website to retrieve the contents of the page, including the CSRF token value
# We then uses the CSRF token value to construct a POST request containing 'data' and stolen CSRF token
# The POST request will be sent to case09 website
# Since the request includes valid CSRF token, the website will interpret the request as legitimate and process it
# Then our code will be executed successfully

python ./case09.py
