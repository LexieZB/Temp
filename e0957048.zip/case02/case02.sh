# Bug Category: SQL Injection
# Target: admin. flag is W5JAU77cnaRSNQP

# The logic of the case02.php is:
# The code check if the 'id' value is set in the URL query string. 
# If it is set, it retrieves the 'id' value and constructs a SQL query
# The SQL query selects the 'first_name' and 'last_name' columns from 'table24' where the 'id' equals the input 'id'
# The code executes the SQL query, store the results in '$result'
# The code outputs 'first_name' and 'last_name'

# Exploit:
# The SQL query is constructed using user input without any form of input validation or sanitization.
# we don't even need code to exploit this webpage, we can just input 'or'1'='1
# Then we can see the name of every user (include the admin)
# In case02.py, we construct an URL contains 'or'1'='1
# This string will be concatenated with this query, the query becomes:
# Select first_name, last_name FROM table24 WHERE id = ''or'1'='1'
# This SQL code is always true, so the query will return all records in 'table24'

python ./exploit02.py