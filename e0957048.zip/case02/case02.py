import webbrowser

url = "http://www.wsb.com/Homework3/case02.php?id='or'1'='1"
new = 2
webbrowser.open(url, new)