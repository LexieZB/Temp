import webbrowser

url = "http://www.wsb.com/Homework3/case01.php?payee=Weibo&sum=10000"

new = 2
webbrowser.open(url,new)