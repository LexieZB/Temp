# Bug Categoty: Parameter Pollution
# Target: The flag is EfTj7BxYg2ywfeD

# The logic of case01.php is:
# 1. If the payee and sum parameters are not set in the URL, the script will display a link to make a payment to "alice" for a sum of $10.
# 2. Else, the script retrieves 'payee' and 'sum' from the URL using $_GET
# 3. The values of these parameters are sanitized using $purifier->purify(). The sanitization can remove dangerous HTML tags and attributes.
# 4. The script will subtract the value of '$clean_sum' from '$bankMoney'. 
# 5. Finally the script will dispaly "Paid payee $sum." and "My bank account has $bankMoney".


# Exploit:
# The website is vulnerable to Parameter Pollution attacks. 
# Although 'payee' and 'sum' are being sanitized using HTMLPurifier, 
# the sanitization does not prevent the attacker from manipulating the URL parameters.
# So the attacker can modify the URL to pay someone else a different amount.


python ./case01.py