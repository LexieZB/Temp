# Bug Categoty: Logic Authentication Flaw
# Target: The flag is a53nAaEvvWSK8G3 

# The logic of case12 is:
# case12 offers a web application for user registeration and login
# Authenticated users could visited the protected page
# The protected_page.php file checks if the user is logged in using the login_check() function. 
# If the user is logged in, a welcome message is displayed.
# If the URL parameter admin is present and set to "true", flag is displayed. 

# Exploit:
# There is a logic authentication flaw in protected_page.php
# protected_page.php checks if the URL parameter admin is set to "true" 
# However, there is no actual authentication or authorization check to ensure that the user is actually an administrator. 
# We could bypass this check by simply adding "?admin=true" to the URL.
# Also we could write codes to automate the attack prcocess

python ./case12.py