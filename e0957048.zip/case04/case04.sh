# Bug Categoty: Unvalidated Redirect
# target: Exploit url and redirect to www.google.com

# The logic of case04.php is:
# The code defines a webpage, the webpage includes a JavaScript function 'redirect()'
# 'redirect()' function will redirect user to another page


# Exploit:
# This website is vulnerable to unvalidated redirects.
# The'redirect' parameter is not validated and could be manipulated by attackers
# http://www.wsb.com/Homework3/case04.php?redirect=https://www.google.com
# This URL opens the webpage with a query parameter 'redirect' set to 'https://www.google.com'

python ./case04.py
