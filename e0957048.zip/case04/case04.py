import webbrowser

url = 'http://www.wsb.com/Homework3/case04.php?redirect=https://www.google.com'
new = 2
webbrowser.open(url, new=new)
