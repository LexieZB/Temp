# Bug Categoty: PHP Injection
# target: The flag is QG3PwQjJmsNnQrx

# The logic of case05.php is:
# The web page has a form that accepts user input in the 'something' field
# The PHP script processes the input using eval() function

# Exploit:
# The user input will not be sanitized or validated.
# We can manipulate the input to gain unauthorized access
# We can even exploit the vulnerability without using any code. 
# By simply inputting the string $flag, we can execute the PHP variable and retrieve target.

python ./case05.py