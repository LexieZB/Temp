import webbrowser

url = 'http://www.wsb.com/Homework3/case05.php?something=%24flag'
new = 2
webbrowser.open(url, new=new)
