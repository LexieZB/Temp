# Bug Category: Reflected XSS
# Target: Flag=S9vjABuASDF9Ddf

# The logic of case08.php is:
# case08 script generates an HTML form that asks for the user's name
# Then it will submit the form data to the same page using the GET method
# The form data is then retrieved using the $_GET superglobal variable.
# If there is input data for the 'name' field, the script removes any occurrence of the '<script>' tag using the str_ireplace() function 
# And concatenates the sanitized input with the HTML code to display a greeting message to the user.

# Exploit:
# We can see that the case08 script is trying to sanitized input by removing <script> tag
# But the sanitization is not sufficient to prevent XSS attack
# Actually we can perform the attack only by input <body onload="alert(document.cookie);"> in the input field
# <body onload> can escape the sanitization.

python ./case08.py