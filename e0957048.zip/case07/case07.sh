# Bug Categoty: Execution after Redirect
# target: The flag is v6xAT3M7Ab67RDy

# The logic of case01.php is:
# The PHP code is a redirect that sends the client to a new location specified by '$redirect_url'

# Exploit:
# We can prevent the client from being redirected to the new location
# We do this by sending a GET request to 'http://www.wsb.com/Homework3/case07.php' with 'allow_redirects' set to False
# The client will stay on the current page and the target will show

python ./case07.py