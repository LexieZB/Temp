import requests, webbrowser

url = 'http://www.wsb.com/Homework3/case07.php'
r = requests.get(url, allow_redirects=False)

with open('target.html', 'w') as f:
        f.write(r.text)

new = 2
webbrowser.open('target.html', new=new)

