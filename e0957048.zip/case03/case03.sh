# Bug Categoty: Local File Inclusion
# target: The flag is urF8uDT7HnnFZTd 

# The logic of case03.php is:
# <select> element offers four options, it also has an 'onchange' event listener that triggers 'loadAnotherLang()'
# 'loadAnotherLang()' function gets the selected language and send it to the server using an AJAX POST request.
# The server receives the request, retrieves the language file and sends it back as a response


# Exploit:
# The 'include' function in PHP code includs a file without proper validation
# We can include and execute code from local files on the server
# We will use 'urllib' and 'urllib2' to send a POST request with the 'LANG' parameter set to '../lfi/txt'
# Then we save the response to 'target.html' and open it in a new browser window.
python ./case03.py
